
class Dog {
int age;
char* name;
public:
   void bark();
   Dog(char* n);
};
