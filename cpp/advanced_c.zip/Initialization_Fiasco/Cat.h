
class Cat {
int age;
char* name;
public:
   void meow();
   Cat(char* n);
};
