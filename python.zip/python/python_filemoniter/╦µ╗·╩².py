import random
import os
print random.uniform(1, 20)   
file =  open('./log.txt', 'a')
for i in range(1, 300*10000 ):
   num = 
   print i
