#coding:utf-8
import time
i = 1
while i <= 3:
    print "睡觉 %d" %i
    i += 1
    ti