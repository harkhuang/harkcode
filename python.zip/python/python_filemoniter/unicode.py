#!/usr/bin/python  
#coding=gbk  
string='我的'  
print string  
s1=unicode(string,"gbk")  
s2=string.decode("gbk")  
print s1  
print s2