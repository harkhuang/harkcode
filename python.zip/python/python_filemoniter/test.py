import random
b_list = range(100001,100200)
blist_webId = random.sample(b_list, 3)
print blist_webId
 