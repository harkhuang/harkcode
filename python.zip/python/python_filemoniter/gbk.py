#coding:gbk 
l=['��','��'.decode('gbk'),'��'.decode('gbk'),'��'.decode('gbk'),'sdfasfsadfasd\dsf\:'.decode('gbk')] 
#print l.count('��'.decode('gbk')) 


print l
1
['\xce\xd2', u'\u6211', u'\u4ed6', u'\u4f60']


#name = u'�۹�gbk'.decode('gbk'1

#print name

['\xce\xd2', u'\u6211', u'\u4ed6', u'\u4f60', u'sdfasfsadfasd']
['\xce\xd2', u'\u6211', u'\u4ed6', u'\u4f60', u'sdfasfsadfasd']
['\xce\xd2', u'\u6211', u'\u4ed6', u'\u4f60', u'sdfasfsadfasd']
['\xce\xd2', u'\u6211', u'\u4ed6', u'\u4f60', u'sdfasfsadfasd\\dsf\\:']
