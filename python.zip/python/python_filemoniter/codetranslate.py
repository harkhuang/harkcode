# -*- coding=gbk2312 -*-
a = "中文"
a_gb2312 = a.encode('gbk2312')
print a_gb2312