#!/usr/bin/python
#Filename:simpleclass.py

class Person:
    pass #An empty block
p = Person
print p
