#!/usr/bin/python
#filename:mymoudledemo.py

import functionmymoudle

mymoudle.sayhi()

print 'Version',mymoudle.version


