def sayHello():	print "hello world"
sayHello();
