#!/usr/bin/python
#file name 

def maxmun(x,y):
	if x>y:
		return x
	else:
		return y

x = maxmun(2,3)
print x
