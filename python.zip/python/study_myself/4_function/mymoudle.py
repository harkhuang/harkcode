#!/usr/bin/python 
#filename:1111mymoudle.py

def sayhi():
	print'hi mymoudle spaking.'

version = '1.0'

#End of mymoudle.py
