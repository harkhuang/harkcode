#!/usr/bin/python
#Filename:function_param.py

def printMax(a,b):
	if a>b:
		print a,'is maxmum'
	else:    #every  keyword must hava a ':' in the end
		print b,'is maxnum'

printMax(3,4)
x=5
y=7
printMax(x,y)