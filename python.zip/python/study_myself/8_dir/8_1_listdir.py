import os 
for fileName in os.listdir('/'):
    print fileName
