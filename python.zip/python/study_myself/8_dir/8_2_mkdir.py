import os

os.mkdir("./aa")
os.rmdir("./aa")

os.makedirs('./a/a/a/a/a/a')
os.removedirs('./a/a/a/a/a/a')
