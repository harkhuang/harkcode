
input = open('data' , 'r')
print (input)
input = open('data') 
print (input)
input = open('data' , 'rb')
print (input)

