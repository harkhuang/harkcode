#!/Python27/python.exe -u 

print("Content-type:text/html")
print('')                      
print('<html>')
print('<head>')
print('<title>Hello</title>')
print('</head>')
print('<body>')
print('<h2>hello CGI</h2>')
print('</body>')
print('</html>')