#!/Python27/python.exe -u 
#coding=utf-8
print "Content-type: text/html\n\n"

print "Hello World!  我是你大爷 <br><br>"
print "<br><br>\n"