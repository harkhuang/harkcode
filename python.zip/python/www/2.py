#!/Python27/python.exe -u 

print "Content-type: text/html\n\n"; 

print "Hello World!22222 <br><br>"; 
print "<br><br>\n";