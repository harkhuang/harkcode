[root@t3kmdsdev1 telnet_install]# rpm -ivh xinetd-2.3.14-34.el6.x86_64.rpm 
warning: xinetd-2.3.14-34.el6.x86_64.rpm: Header V4 DSA/SHA1 Signature, key ID 192a7d7d: NOKEY
Preparing...                ########################################### [100%]
   1:xinetd                 ########################################### [100%]

[root@t3kmdsdev1 telnet_install]# rpm -ivh telnet-server-0.17-47.el6.x86_64.rpm 
warning: telnet-server-0.17-47.el6.x86_64.rpm: Header V4 DSA/SHA1 Signature, key ID 192a7d7d: NOKEY
Preparing...                ########################################### [100%]
   1:telnet-server          ########################################### [100%]

[root@t3kmdsdev1 telnet_install]# rpm -ivh telnet-0.17-47.el6.x86_64.rpm 
warning: telnet-0.17-47.el6.x86_64.rpm: Header V4 DSA/SHA1 Signature, key ID 192a7d7d: NOKEY
Preparing...                ########################################### [100%]
   1:telnet                 ########################################### [100%]
